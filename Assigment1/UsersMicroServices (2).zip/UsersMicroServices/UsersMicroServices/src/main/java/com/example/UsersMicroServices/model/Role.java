package com.example.UsersMicroServices.model;

public enum Role {
    ADMIN, USER;
}
