package com.example.DevicesMicroservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevicesMicroservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
