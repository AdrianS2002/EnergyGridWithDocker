package com.example.UsersMicroServices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsersMicroServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsersMicroServicesApplication.class, args);
	}

}
