package com.example.DevicesMicroservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevicesMicroservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(DevicesMicroservicesApplication.class, args);
	}

}
